---
layout: en
title: Imprint
permalink: /imprint.html
---

<article id="imprint">
  <address>
    Travis CI GmbH<br>
    Rigaer Straße 8<br>
    10247 Berlin<br>
    Germany
  </address>
  <h4>Vertreten durch</h4>
  <p>Mathias Meyer, Fritz Thielemann</p>
  <h4>Kontakt</h4>
  <p>
    Email contact@travis-ci.org <br>
    Telefon +49 160 4201564
  </p>
  <h4>Registereintrag</h4>
  <p>HRB 140133 B</p>
  <h4>Umsatzsteuer-ID gemäß §27 a Umsatzsteuergesetz</h4>
  <p>DE282002648</p>
  <h4>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h4>
  <address>
    Travis CI GmbH<br>
    Mathias Meyer, Fritz Thielemann<br>
    Rigaer Straße 8<br>
    10247 Berlin<br>
    Germany
  </address>
</article>
