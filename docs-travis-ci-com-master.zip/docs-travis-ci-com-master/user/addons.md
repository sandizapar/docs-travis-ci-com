---
title: Build Addons
layout: en

---

This page is deprecated. The integrations previously listed here have been
moved:

- [Sauce Connect](/user/sauce-connect/)
- [Custom Host Names](/user/hosts/)
- [MariaDB](/user/database-setup/#MariaDB)
- [PostgreSQL](/user/database-setup/#PostgreSQL)
- [RethinkDB](/user/database-setup/#RethinkDB)
- [Firefox](/user/firefox/)
