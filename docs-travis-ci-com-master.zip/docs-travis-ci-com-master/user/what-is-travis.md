---
title: What is Travis CI
layout: en

---

What is Travis CI?

- Travis CI is continuous integration for projects hosted on GitHub.
- Travis CI is automation for testing building and deploying.
- Travis CI gives you peace of mind when developing.
- Travis CI lets you know as soon as something goes wrong.
